# Trabalho prático - Prova 3
### Discente: Marlon Fabichacki Pereira

Compile os arquivos com `make`.

Execute o analisador léxico e sintático com `./lang < teste.in`.